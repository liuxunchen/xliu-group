#!/usr/bin/env bash
# 生成 Example 8 代码包的完整输出文本（供博客引用与下载）
# 在 55 上运行：bash make_outputs.sh
set -u
cd "$(dirname "$0")"
OUT=OUTPUT-example8.txt
: > "$OUT"

{
  echo "========================================================================"
  echo " Example 8 完整计算输出：液氢/液氧火箭喷管（HP → SP）"
  echo " 工况：O/F = 6.0（质量比）、p_c = 206.843 bar、推进剂 298.15 K、绝热等熵"
  echo " 机制：gri30（53 物种 / 325 反应）；冻结流在高物种数下求解"
  echo " 运行环境：$(python3 -V 2>&1)；cantera $(python3 -c 'import cantera;print(cantera.__version__)' 2>/dev/null)；"
  echo "           numpy $(python3 -c 'import numpy;print(numpy.__version__)' 2>/dev/null)；scipy $(python3 -c 'import scipy;print(scipy.__version__)' 2>/dev/null)"
  echo " 生成时间：$(date '+%Y-%m-%d %H:%M:%S')"
  echo "========================================================================"
} >> "$OUT"

run() {
  echo "" >> "$OUT"
  echo "------------------------------------------------------------------------" >> "$OUT"
  echo "\$ python3 $1" >> "$OUT"
  echo "------------------------------------------------------------------------" >> "$OUT"
  timeout 600 python3 "$1" >> "$OUT" 2>&1 || echo "（脚本退出码 $?）" >> "$OUT"
}

run ex8_correct_numbers.py
run verify_throat_strict.py
run ex8_scan_table.py
run ex8_full.py

echo "" >> "$OUT"
echo "============================= 输出结束 =================================" >> "$OUT"
echo "已生成 $OUT（$(wc -l < "$OUT") 行，$(stat -c%s "$OUT") 字节）"
