#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""冻结流沿等熵线扫描表（修正版，供例题/博客引用）：输出 u-a 由负变正的相邻点。"""
import numpy as np
import cantera as ct
from scipy.optimize import brentq

PC = 206.843e5
MO2, MH2 = 31.9988, 2.01588
nH2 = MO2 / (6.0 * MH2)
g = ct.Solution("gri30.yaml")
g.TPX = 298.15, PC, {"O2": 1.0, "H2": nH2}
h0 = g.enthalpy_mass
g.equilibrate("HP")
Tc, s_c, Xc = g.T, g.entropy_mass, g.X.copy()

def st(p):
    gas = ct.Solution("gri30.yaml")
    T = brentq(lambda T: (setattr(gas, "TPX", (T, p, Xc)), gas.entropy_mass - s_c)[1],
               250.0, 4200.0, xtol=1e-7)
    u = np.sqrt(max(2.0 * (h0 - gas.enthalpy_mass), 0.0))
    return T, u, gas.sound_speed

print("| 沿等熵线的量 | " + " | ".join(f"{p/1e5:.1f} bar" for p in
      [PC, 175e5, 155e5, 134e5, 120e5, 116.9e5, 113.8e5, 93.1e5]) + " |")
rows = {"T": [], "u": [], "a": [], "d": []}
for p in [PC, 175e5, 155e5, 134e5, 120e5, 116.9e5, 113.8e5, 93.1e5]:
    T, u, a = st(p)
    rows["T"].append(f"{T:.1f}")
    rows["u"].append(f"{u:.0f}")
    rows["a"].append(f"{a:.0f}")
    rows["d"].append(f"{u-a:+.1f}")
print("| $T$ / K | " + " | ".join(rows["T"]) + " |")
print("| $u$ / (m/s) | " + " | ".join(rows["u"]) + " |")
print("| $a$ / (m/s) | " + " | ".join(rows["a"]) + " |")
print("| $u-a$ / (m/s) | " + " | ".join(rows["d"]) + " |")

# 精确喉道
prev = None; pt = None
for p in np.linspace(PC * 0.98, PC * 0.30, 220):
    T, u, a = st(p)
    if prev and (prev[1] - prev[2]) * (u - a) < 0:
        pt = brentq(lambda p: (lambda r: r[1] - r[2])(st(p)), prev[0], p, xtol=0.5)
        break
    prev = (p, u, a)
T, u, a = st(pt)
gas = ct.Solution("gri30.yaml")
gas.TPX = T, pt, Xc
print(f"\n喉道: p_t = {pt/1e5:.2f} bar ({pt/PC:.4f} p_c)  T_t = {T:.1f} K  u_t = a_t = {u:.1f} m/s")
print(f"      γ_t = {gas.cp_mass/gas.cv_mass:.4f}  ρ_t = {gas.density:.4f} kg/m³  ṁ/A_t = {gas.density*u:.0f} kg/(m²s)")
