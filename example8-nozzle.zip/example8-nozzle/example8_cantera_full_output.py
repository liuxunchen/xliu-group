#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Cantera 完整输出（供博客引用）：液氢/液氧 O/F=6.0、p_c=206.843 bar 的燃烧室与喷管计算。

① 燃烧室 HP：T_c、全部非零组分（含次要组分）、s_c、γ
② 与"5 物种 JANAF 手算"逐项对比（说明复杂化学反应带来的细微差别）
③ 喉道 M=1（冻结流 / 平衡流）
"""
import numpy as np
import cantera as ct

PC = 206.843e5
MO2, MH2 = 31.9988, 2.01588
NO2 = 1.0
NH2 = MO2 / (6.0 * MH2)                 # O/F = 6.0（质量比）

g = ct.Solution("gri30.yaml")
g.TPX = 298.15, PC, {"O2": NO2, "H2": NH2}
print(f"反应物：{NO2:.3f} mol O2 + {NH2:.4f} mol H2   O/F = {MO2/(NH2*MH2):.3f}")
print(f"机制：gri30（{g.n_species} 物种 / {g.n_reactions} 反应）   Cantera {ct.__version__}")

g.equilibrate("HP")
print("\n=== ① 燃烧室 HP 平衡（Cantera）===")
print(f"T_c = {g.T:.1f} K     p_c = {PC/1e5:.3f} bar")
print(f"M̄W = {g.mean_molecular_weight:.4f} g/mol    γ = {g.cp_mass/g.cv_mass:.4f}")
print(f"s_c = {g.entropy_mass:.1f} J/(kg K) = {g.entropy_mass*g.mean_molecular_weight/1000:.2f} J/(mol K)")
print("非零组分（摩尔分数 > 1e-6）：")
for i in range(g.n_species):
    x = g.X[i]
    if x > 1e-6:
        print(f"    {g.species_name(i):8s} {x:.6f}")
print(f"  次要组分合计 = {sum(g.X[i] for i in range(g.n_species) if g.X[i] > 1e-6 and g.species_name(i) not in ('H2O','H2','O2','H','OH')):.2e}")

print("\n=== ② 与 5 物种 JANAF 手算的对比 ===")
hand = {"H2O": 0.661, "H2": 0.249, "O2": 0.004, "H": 0.035, "OH": 0.051}
print(f"{'物种':8s} {'Cantera':>10s} {'手算':>8s} {'差':>9s}")
for s, xh in hand.items():
    xc = g.X[g.species_index(s)]
    print(f"{s:8s} {xc:10.4f} {xh:8.3f} {xc-xh:+9.4f}")
print(f"{'T_c / K':8s} {g.T:10.1f} {3756:8.0f} {g.T-3756:+9.1f}")

print("\n=== ③ 喉道 M=1（冻结流 / 平衡流）===")
from scipy.optimize import brentq
Tc_save, Yc = g.T, g.Y.copy()          # 燃烧室平衡态（冻结流的起点）
s_c, h0 = g.entropy_mass, g.enthalpy_mass

def state_of(frozen):
    """每次新建 Solution，避免冻结/平衡互相污染状态。"""
    gas = ct.Solution("gri30.yaml")
    gas.TPY = Tc_save, PC, Yc

    def state(p):
        if frozen:
            T = brentq(lambda T: (setattr(gas, "TPY", (T, p, Yc)), gas.entropy_mass - s_c)[1],
                       250.0, 4200.0, xtol=1e-6)
        else:
            gas.SP = s_c, p
            gas.equilibrate("SP")
            T = gas.T
        u = np.sqrt(max(2.0 * (h0 - gas.enthalpy_mass), 0.0))
        return T, u, gas.sound_speed, gas.density
    return gas, state

for frozen in (True, False):
    gas, state = state_of(frozen)
    prev = None
    for p in np.linspace(PC * 0.95, PC * 0.30, 140):
        T, u, a, _ = state(p)
        if prev and (prev[1] - prev[2]) * (u - a) < 0:
            pt = brentq(lambda p: (lambda r: r[1] - r[2])(state(p)), prev[0], p, xtol=1.0)
            T, u, a, rho = state(pt)
            print(f"   {'冻结流' if frozen else '平衡流'}: p_t = {pt/1e5:.2f} bar   T_t = {T:.0f} K   "
                  f"u_t = a_t = {u:.0f} m/s   ρ_t·u_t = {rho*u:.0f} kg/(m²s)")
            if not frozen:
                nz = [(gas.species_name(i), gas.X[i]) for i in range(gas.n_species) if gas.X[i] > 1e-4]
                print("        喉道主要组分: " + "  ".join(f"{k}={v:.4f}" for k, v in nz))
            break
        prev = (p, u, a)
