# Example 8 可复现代码包：液氢/液氧火箭喷管（HP → SP）

> 配套博客：[**从氢氧焰到液氢液氧火箭喷管：HP/SP 到底在算什么**](https://liuxunchen.github.io/xliu-group/zh/post/janaf-cea-nozzle-hp-sp/)
> 工况：$\mathrm{O/F}=6.0$（质量比）、$p_c=206.843$ bar、推进剂 298.15 K、喷管绝热等熵。

## 环境

```bash
pip install numpy scipy cantera      # Cantera ≥ 3.0（本包用 3.2.0 验证）
```

`janaf_data/` 内为 JANAF 第四版原始物种表（16 个物种，制表符分隔），
`ex8_full.py` 等纯 JANAF 脚本**不需要 Cantera**，只用 numpy + scipy。

## 脚本清单

| 脚本 | 作用 | 依赖 |
|:--|:--|:--|
| `ex8_correct_numbers.py` | **主脚本**：燃烧室 HP → 喉道 $u_t=a_t$ 迭代（冻结/平衡）→ 出口表与 $I_{sp}$；输出博客中全部数值 | cantera + scipy |
| `verify_throat_strict.py` | **喉道严格验证**：三种冻结口径（TPX/TPY/SPY）分别求 $M=1$，并代回检查 $u-a$ 与 $s-s_c$ | cantera + scipy |
| `ex8_scan_table.py` | 沿等熵线的扫描表（$T,u,a,u-a$ vs $p$），即博客中那张表 | cantera + scipy |
| `example8_cantera_full_output.py` | 燃烧室完整组分（含次要组分 O/HO₂/H₂O₂）与 5 物种手算对比 | cantera + scipy |
| `ex8_full.py` | **纯 JANAF 手算口径**：5 物种 HP 解（$T_c\approx3756$ K）与下游量 | numpy + scipy |
| `janaf_data/` | JANAF 第四版原始物种表（16 个物种） | — |

## 运行

```bash
python3 ex8_correct_numbers.py            # ≈ 1–2 分钟（出口扫描较慢）
python3 verify_throat_strict.py
python3 ex8_scan_table.py
python3 example8_cantera_full_output.py
python3 ex8_full.py                       # 不需要 Cantera
```

## 关键结果（本包验证值）

| 量 | 冻结流 | 平衡流 |
|:--|--:|--:|
| 燃烧室 $T_c$ | 3729.8 K（纯 JANAF 手算 3756 K） | 同 |
| 喉道 $p_t$ | **116.87 bar**（$p_t/p_c$=0.5650） | 116.38 bar |
| 喉道 $T_t$ | **3398 K** | 3507 K |
| $u_t=a_t$ | 1586 m/s | 1600 m/s |
| $\dot m/A_t$；$c^*$ | 8819 kg/(m²·s)；2345 m/s | 8679；— |
| 出口 $I_{sp,vac}$（$A_e/A_t$=3→45） | 325→432 s | 328→449 s |

> ⚠️ 若你看到 $p_t\approx124$ bar：那来自"冻结流取冻结态焓作滞止焓"的写法，
> 该点不满足 $M=1$（$u-a=-57$ m/s）。用 `verify_throat_strict.py` 可复现这一判定。

## γ 常数阻塞式能用吗（5.3 节那条近似）

$$\frac{p_t}{p_c}=\left(\frac{2}{\gamma_c+1}\right)^{\gamma_c/(\gamma_c-1)}$$

代入室值 $\gamma_c=1.1927$ 得 $p_t/p_c=0.56590$（117.05 bar），严格解为 0.56503（116.87 bar）——
**偏差 $\varepsilon=(p_t^{\rm block}-p_t^{\rm strict})/p_c=+0.087\%$**。但它不是普适的小量：

| 推进剂 | $\gamma_c$ | $\Delta\gamma=\gamma_t-\gamma_c$ | $\varepsilon$ / % |
|:--|--:|--:|--:|
| H₂/O₂（O/F=6） | 1.1927 | 0.0041 | +0.087 |
| H₂/O₂（O/F=3） | 1.2354 | 0.0068 | +0.142 |
| CH₄/O₂（O/F=3.2） | 1.2007 | 0.0030 | +0.065 |
| H₂/空气（O/F=4） | 1.3540 | 0.0103 | +0.199 |

规律 $\varepsilon=k\,\Delta\gamma$，$k=21.4\pm0.16$（O/F=3~8 全程；换推进剂为 21.5 / 19.4）。
即：**误差由 $\gamma$ 偏离 1.2 的程度决定，与工况无关**。用喉道值 $\gamma_t$ 代入可把偏差降到 0.008%。
复算脚本与图：`5-PPT-figure/ex8-blockage-error/`（`scan_of.py` → `scan_h2o2.csv` → `plot_figB.py`）。
