#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""严格对照：冻结流 M=1 到底在 124.4 还是 116.9 bar？

（2026-09-14 附注）本脚本的冻结流解 p_t=116.872 bar 是 γ 常数阻塞式的对照基准：
阻塞式用 γ_c=1.1927 给 0.56590，比严格解 0.56503 高 0.087%（=0.18 bar）；
该偏差 ≈21.4·(γ_t−γ_c)，随 γ 偏离 1.2 而增大（H2/air 约 0.20%）。
详见 5-PPT-figure/ex8-blockage-error/ 与 Ex8-计算方法与物理图像.md 第 2′ 步。

对同一燃烧室态，用三种方式定义"冻结流"并各自求 M=1：
  ① TPX 固定摩尔分数（导师 ex8_cantera.py 的写法）
  ② TPY 固定质量分数（我的写法）
  ③ SPY 固定组成 + 指定熵
并对每个解代回 (u-a) 与 (s-s_c) 做自洽性检查。
"""
import numpy as np
import cantera as ct
from scipy.optimize import brentq

PC = 206.843e5
MO2, MH2 = 31.9988, 2.01588
nH2 = MO2 / (6.0 * MH2)
MAIN = ["H2O", "H2", "O2", "H", "OH"]

g0 = ct.Solution("gri30.yaml")
g0.TPX = 298.15, PC, {"O2": 1.0, "H2": nH2}
h_react = g0.enthalpy_mass
g0.equilibrate("HP")
Tc, s_c = g0.T, g0.entropy_mass
Xc53 = g0.X.copy()
Yc53 = g0.Y.copy()
print(f"燃烧室: T_c = {Tc:.1f} K, s_c = {s_c:.1f} J/(kg K), h_react = {h_react/1e6:.6f} MJ/kg")
print("  5 主组分摩尔分数: " + "  ".join(f"{s}={g0.X[g0.species_index(s)]:.4f}" for s in MAIN))

def throat(mode):
    """返回 (p_t, T_t, u_t, a_t, 自洽检查)"""
    gas = ct.Solution("gri30.yaml")

    def set_state(p, T):
        if mode == "TPX":
            gas.TPX = T, p, Xc53
        elif mode == "TPY":
            gas.TPY = T, p, Yc53
        else:  # SPY
            gas.SPY = s_c, p, Yc53

    def resid(p):
        if mode == "SPY":
            set_state(p, None)
            T = gas.T
        else:
            T = brentq(lambda T: (set_state(p, T), gas.entropy_mass - s_c)[1], 250.0, 4200.0, xtol=1e-7)
        u = np.sqrt(max(2.0 * (h_react - gas.enthalpy_mass), 0.0))
        return u - gas.sound_speed

    prev = None
    lo = hi = None
    for p in np.linspace(PC * 0.98, PC * 0.30, 200):
        v = resid(p)
        if prev and prev[1] * v < 0:
            lo, hi = prev[0], p
            break
        prev = (p, v)
    if lo is None:
        return None
    pt = brentq(resid, lo, hi, xtol=1.0)
    if mode == "SPY":
        set_state(pt, None)
        Tt = gas.T
    else:
        Tt = brentq(lambda T: (set_state(pt, T), gas.entropy_mass - s_c)[1], 250.0, 4200.0, xtol=1e-7)
    u = np.sqrt(max(2.0 * (h_react - gas.enthalpy_mass), 0.0))
    return pt, Tt, u, gas.sound_speed, gas.entropy_mass - s_c

print(f"\n{'定义方式':10s} {'p_t/bar':>9s} {'T_t/K':>7s} {'u_t':>6s} {'a_t':>6s} {'u-a':>7s} {'s-s_c':>9s}")
for mode in ("TPX", "TPY", "SPY"):
    try:
        r = throat(mode)
        if r is None:
            print(f"{mode:10s}   未找到 M=1 交点")
        else:
            pt, Tt, u, a, ds = r
            print(f"{mode:10s} {pt/1e5:9.2f} {Tt:7.0f} {u:6.0f} {a:6.0f} {u-a:+7.1f} {ds:+9.2f}")
    except Exception as e:
        print(f"{mode:10s}   失败: {str(e)[:50]}")

# 对两个候选点做自洽性检查（用 TPX 冻结口径）
print("\n候选点自洽性（TPX 冻结口径）:")
gas = ct.Solution("gri30.yaml")
for p_bar, T in [(124.43, 3420), (116.87, 3398)]:
    gas.TPX = T, p_bar * 1e5, Xc53
    u = np.sqrt(max(2.0 * (h_react - gas.enthalpy_mass), 0.0))
    print(f"  p={p_bar:7.2f} bar T={T} K -> u={u:6.0f} a={gas.sound_speed:6.0f} u-a={u-gas.sound_speed:+7.1f} "
          f"s-s_c={gas.entropy_mass-s_c:+8.2f}")
