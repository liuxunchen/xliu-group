#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Correct Ex8 numbers (throat p_t = 116.87 bar) —— 冻结/平衡双口径出口表与比冲。

滞止态：O/F=6.0、p_c=206.843 bar、298.15 K 元素标准态（h0 = 反应物焓 = 0）
喉道：固定燃烧室组成或平衡膨胀，条件 u_t = a_t
出口：给定 A_e/A_t，由 mdot/A = rho*u 沿等熵线求交集
"""
import warnings
import numpy as np
import cantera as ct

warnings.filterwarnings("ignore", message=".*outside valid range.*")
from scipy.optimize import brentq

PC = 206.843e5
MO2, MH2, G0 = 31.9988, 2.01588, 9.80665
nH2 = MO2 / (6.0 * MH2)
MAIN = ["H2O", "H2", "O2", "H", "OH"]

# ---- 滞止态（燃烧室）----
g = ct.Solution("gri30.yaml")
g.TPX = 298.15, PC, {"O2": 1.0, "H2": nH2}
h0 = g.enthalpy_mass
g.equilibrate("HP")
Tc, s_c = g.T, g.entropy_mass
Xc53, Yc53 = g.X.copy(), g.Y.copy()
print(f"① 燃烧室: T_c = {Tc:.1f} K, p_c = {PC/1e5:.3f} bar, s_c = {s_c:.1f} J/(kg K)")
print("   组成: " + "  ".join(f"{s}={g.X[g.species_index(s)]:.4f}" for s in MAIN))
print(f"   γ = {g.cp_mass/g.cv_mass:.4f},  C̄p = {g.cp_mass:.1f} J/(kg K)")

def make_state(frozen):
    gas = ct.Solution("gri30.yaml")
    gas.TPX = Tc, PC, Xc53
    def state(p):
        if frozen:
            T = brentq(lambda T: (setattr(gas, "TPX", (T, p, Xc53)), gas.entropy_mass - s_c)[1],
                       250.0, 4200.0, xtol=1e-7)
        else:
            gas.SP = s_c, p
            gas.equilibrate("SP")
            T = gas.T
        u = np.sqrt(max(2.0 * (h0 - gas.enthalpy_mass), 0.0))
        return T, u, gas.sound_speed, gas.density
    return gas, state

print("\n② 喉道 (u_t = a_t)")
throat = {}
for frozen in (True, False):
    gas, state = make_state(frozen)
    prev = None; pt = None
    for p in np.linspace(PC * 0.98, PC * 0.30, 220):
        T, u, a, rho = state(p)
        if prev and (prev[1] - prev[2]) * (u - a) < 0:
            pt = brentq(lambda p: (lambda r: r[1] - r[2])(state(p)), prev[0], p, xtol=1.0)
            break
        prev = (p, u, a)
    T, u, a, rho = state(pt)
    mdotA = rho * u
    throat[frozen] = (pt, T, u, a, rho, mdotA, state)
    tag = "冻结流" if frozen else "平衡流"
    print(f"   {tag}: p_t = {pt/1e5:.2f} bar ({pt/PC:.4f} p_c)   T_t = {T:.0f} K   "
          f"u_t = a_t = {u:.0f} m/s   ρ_t = {rho:.4f}   ṁ/A_t = {mdotA:.0f} kg/(m²s)   γ_t = {gas.cp_mass/gas.cv_mass:.4f}")

cstar = PC / throat[True][5]
print(f"   c* = p_c/(ṁ/A_t) = {cstar:.0f} m/s (冻结流)")

print("\n③ 出口 (A_e/A_t 给定)")
for Ae in (3, 10, 20, 45):
    for frozen in (True, False):
        pt, Tt, ut, at, rhot, mdotA, state = throat[frozen]
        best = None
        for p in np.logspace(np.log10(pt), 2.5, 700):   # 出口扫描下限 2.5 bar（低于此已在大面积比之外）
            try:
                T, u, a, rho = state(p)
            except Exception:
                continue
            A = mdotA / (rho * u)
            if best is None or abs(A - Ae) < abs(best[0] - Ae):
                best = (A, T, p, u, a, rho)
        A, Te, pe, ue, ae, rho_e = best
        tag = "冻结" if frozen else "平衡"
        print(f"   Ae/At={Ae:>2} {tag}: Te={Te:6.0f} K  pe={pe/1e5:8.4f} bar  ue={ue:6.0f} m/s  "
              f"Me={ue/ae:4.2f}  Isp_vac={ue/G0:6.1f} s  CF={ue/cstar:.3f}")
