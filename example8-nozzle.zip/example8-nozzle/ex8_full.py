#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ex8 完整独立求解 —— JANAF 第四版原表
HP 平衡求 T_c + 组成，再重算下游 s_c / C̄_p / γ / p_t / T_t
与论文现行稿（T_c=3756 K、p_t=116.87 bar、T_t=3398 K 冻结 / 3507 K 平衡）对比。
口径注：本脚本 p_t 走 γ 常数阻塞式近似（正文 Step 3 明说为近似），
故 T_t 略高于严格 u_t=a_t 解（116.87 bar / 3398 K）。
"""
import os
import numpy as np
from scipy.optimize import root, brentq

R = 8.314462618
T0 = 298.15
P0 = 1e5
HERE = os.path.dirname(os.path.abspath(__file__))
DATADIR = os.path.join(HERE, "janaf_data")
Pc = 206.843e5

FILE_MAP = {
    "H2O": ["H2O.txt", "H-064.txt"], "H2": ["H2.txt", "H-050.txt"],
    "O2": ["O2.txt", "O-029.txt"], "H": ["H.txt"], "OH": ["HO.txt"],
}

def load(fn):
    rows = []
    with open(fn, encoding="utf-8", errors="replace") as fh:
        for ln in fh:
            f = ln.rstrip("\n").split("\t")
            if len(f) < 8:
                continue
            try:
                v = [float(x) if x.strip() != "INFINITE" else np.nan for x in f]
                rows.append(v)
            except (ValueError, IndexError):
                continue
    return np.array(rows)

def ip(arr, T, col):
    Tarr = arr[:, 0]; v = arr[:, col]; m = np.isfinite(v)
    return float(np.interp(T, Tarr[m], v[m]))

specs = {}
for sp in ["H2O", "H2", "O2", "H", "OH"]:
    for fn in FILE_MAP[sp]:
        p = os.path.join(DATADIR, fn)
        if os.path.exists(p):
            specs[sp] = load(p); break

SPLIST = ["H2O", "H2", "O2", "H", "OH"]
ELEM = {"H2O": (2,1), "H2": (2,0), "O2": (0,2), "H": (1,0), "OH": (1,1)}
aH = np.array([ELEM[s][0] for s in SPLIST], float)
aO = np.array([ELEM[s][1] for s in SPLIST], float)

n_H2 = 31.9988 / (6.0 * 2.01588)   # 以 1 mol O2 为基准，n_H2 ≈ 2.6456
bH = 2 * n_H2; bO = 2.0

def H_abs(sp, T):   # J/mol，元素 298.15 为零点
    return ip(specs[sp], 298.15, 5)*1000 + ip(specs[sp], T, 4)*1000
def dGf(sp, T):     # J/mol
    return ip(specs[sp], T, 6)*1000
def S_std(sp, T):   # J/(mol K)
    return ip(specs[sp], T, 2)
def Cp(sp, T):      # J/(mol K)
    return ip(specs[sp], T, 1)

def equilibrium(T):
    def eqn(z):
        y = z[:5]; psiH, psiO, L = z[5], z[6], z[7]
        n = np.exp(y); n_tot = np.exp(L); res = np.zeros(8)
        for i, sp in enumerate(SPLIST):
            res[i] = dGf(sp, T)/(R*T) + (y[i] + np.log(Pc/P0) - L) - aH[i]*psiH - aO[i]*psiO
        res[5] = np.dot(aH, n) - bH
        res[6] = np.dot(aO, n) - bO
        res[7] = np.sum(n) - n_tot
        return res
    z0 = np.zeros(8)
    z0[:5] = np.log([1.0, 0.3, 0.2, 0.05, 0.05])
    z0[7] = np.log(2.0)
    sol = root(eqn, z0, method="hybr", tol=1e-12)
    return np.exp(sol.x[:5]) if sol.success else None

def H_prod(T):
    n = equilibrium(T)
    return None if n is None else sum(n[i]*H_abs(SPLIST[i], T) for i in range(5))

# 精确求 T_c：先扫描定位跨零区间，再二分
Ts = np.arange(3000, 4201, 50.0)
lo, hi = None, None
prev_T, prev_h = None, None
for T in Ts:
    h = H_prod(T)
    if h is None:
        continue
    if prev_h is not None and prev_h * h < 0:
        lo, hi = prev_T, T
        break
    prev_T, prev_h = T, h
assert lo is not None, "未找到跨零区间"
Tc = brentq(H_prod, lo, hi, xtol=1e-8)
n = equilibrium(Tc)
n_tot = np.sum(n)
y = n / n_tot

print("=" * 66)
print(f"【HP 平衡解】T_c = {Tc:.2f} K")
print("组成（摩尔分数）：")
for i, sp in enumerate(SPLIST):
    print(f"   {sp:4s}  y = {y[i]:.4f}")
print(f"   n_tot = {n_tot:.4f}（基准 1 mol O2）")

# 熵、焓复算
s_mix = sum(y[i]*S_std(SPLIST[i], Tc) for i in range(5))
h_mix = sum(n[i]*H_abs(SPLIST[i], Tc) for i in range(5))/1000
print(f"   Σ y_i S_i(T_c) = {s_mix:.2f} J/(mol K)")
print(f"   H_prod(T_c)    = {h_mix:+.3f} kJ/mol-O2（要求 0）")

# 下游重算
Cp_mix = sum(y[i]*Cp(SPLIST[i], Tc) for i in range(5))
gamma = Cp_mix / (Cp_mix - R)
pt_ratio = (2/(gamma+1))**(gamma/(gamma-1))
pt = pt_ratio * Pc / 1e5  # bar
s_c = s_mix - R*np.log(Pc/P0)
pt_Pa = pt * 1e5

print("\n【下游重算】")
print(f"   C̄_p = {Cp_mix:.2f} J/(mol K)")
print(f"   γ = {gamma:.4f}")
print(f"   p_t/p_c = {pt_ratio:.4f}")
print(f"   p_t = {pt:.1f} bar")
print(f"   s_c = s°_mix - R ln(p_c/p°) = {s_mix:.2f} - {R*np.log(Pc/P0):.2f} = {s_c:.2f} J/(mol K)")

# T_t：冻结组成等熵
def s_mix_frozen(T):
    return sum(y[i]*S_std(SPLIST[i], T) for i in range(5))
target = s_c + R*np.log(pt_Pa/P0)
def g(T): return s_mix_frozen(T) - target
Tt = brentq(g, 2500, 4500, xtol=1e-8)
print(f"   冻结组成 s°_mix(T_t) 目标 = {target:.2f} J/(mol K)")
print(f"   T_t = {Tt:.1f} K")

print("\n【与论文对比】")
print(f"   论文现行稿：T_c=3756, p_t=116.87 bar（u_t=a_t 迭代）, T_t=3398（冻结）/3507 K（平衡）")
print(f"   本脚本（JANAF 原表 + γ 阻塞式近似）：T_c={Tc:.0f}, T_t={Tt:.0f}, γ={gamma:.2f}, p_t={pt:.1f}")

# ---- Step 4 中间值（供正文替换）----
Rln_pc = R*np.log(Pc/P0)
Rln_pt = R*np.log(pt_Pa/P0)
print("\n【Step 4 正文替换值】")
print(f"   s°_mix(T_c) = {s_mix:.2f}")
print(f"   R ln(p_c/p°) = {Rln_pc:.2f}")
print(f"   s_c = {s_mix:.2f} - {Rln_pc:.2f} = {s_mix-Rln_pc:.2f}")
print(f"   R ln(p_t/p°) = {Rln_pt:.2f}")
print(f"   目标 s°_mix(T_t) = {s_mix-Rln_pc+Rln_pt:.2f}")
for T in [3300, 3400, 3500]:
    sf = sum(y[i]*S_std(SPLIST[i], T) for i in range(5))
    print(f"   冻结组成 s°_mix({T} K) = {sf:.2f}")

